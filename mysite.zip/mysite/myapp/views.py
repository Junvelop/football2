from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
import requests
from googletrans import Translator

def translate_to_korean(text):
    translator = Translator()
    translation = translator.translate(text, src='en', dest='ko')
    return translation.text

def prefer_team(request):
    teams = [
        {'id': 61, 'name': 'Arsenal'},
        {'id': 62, 'name': 'Aston Villa'},
        # 나머지 팀들 추가
    ]

    # 팀 정보를 가져와서 추가
    for team in teams:
        team_id = team['id']
        team_info = get_team_info(team_id)
        team['description'] = team_info['korean_description']

    return render(request, 'prefer_team.html', {'teams': teams})

def save_data(request):
    if request.method == 'POST':
        data = request.json()

        # 여기에서 데이터를 저장하거나 필요한 동작을 수행합니다.
        # 예를 들어, 데이터베이스에 저장할 수 있습니다.

        return JsonResponse({'message': '데이터가 성공적으로 저장되었습니다.'})
    else:
        return HttpResponse(status=400)

def get_team_info(team_id):
    # TheSportsDB API 호출
    api_key = "3"
    url = f"https://www.thesportsdb.com/api/v1/json/{api_key}/searchteams.php?t={team_id}"

    

    response = requests.get(url)
    data = response.json()

    # API에서 가져온 데이터에서 영어 설명 추출
    english_description = data["teams"][0]["strDescriptionEN"]

    # 번역
    korean_description = translate_to_korean(english_description)

    return {'korean_description': korean_description}
